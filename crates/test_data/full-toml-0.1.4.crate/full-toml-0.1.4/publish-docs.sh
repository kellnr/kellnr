cd target
curl -H "Authorization: Zy9HhJ02RJmg0GCrgLfaCVfU6IwDfhXD" http://localhost:8000/api/v1/docs/full-toml/0.1.4 --upload-file doc.zip