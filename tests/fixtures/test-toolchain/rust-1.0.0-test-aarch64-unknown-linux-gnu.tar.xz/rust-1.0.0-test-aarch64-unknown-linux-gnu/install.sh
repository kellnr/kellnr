#!/bin/bash
echo "Test toolchain install"
exit 0
